=== Cpt custom page template ===
Contributors: ganeshpaygude,clarionwpdeveloper
Tags: custom-template,cpt-template,cpttemplates.
Requires at least: 3.2
Tested up to: 4.4.1
Stable tag: 1.0
License: GPLv2

Adding Template Options to a Wordpress Custom Post Type

== Description ==

Adding Template Options to a Wordpress Custom Post Type

Major features in Cpt custom page template  include:

* Adding Template Options to a Wordpress Custom Post Type

== Installation ==


1. Upload the plugin files to the '/wp-content/plugins/' directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress


== Frequently Asked Questions ==


== Screenshots ==

1.screenshot-1 


== Changelog ==

= 1.0 =
* current version 1.0 


== Upgrade Notice ==

= 1.0 =
currently no upgrades sections

== Arbitrary section ==


== A brief Markdown Example ==

